

##Projet CAI



##Nom

EL ALAMI Adam
Elisee GUEPY LONKENG
Kyrian PENILLON
Roua BOUGHANMI

<!-- 
## Installation

1. Clonez ce dépôt ou téléchargez-le.
   ```bash
   git clone https://git.enib.fr/k0penill/cai-restauration.git
   ```
2. Naviguez dans le répertoire du projet.
   ```bash
   cd cai-restauration
   ```
3. Installez les dépendances nécessaires.
   ```bash
   npm install
   ``` -->
<!-- ## Démarrage en mode développement

Pour lancer l'application en mode développement, exécutez la commande suivante :

1.  
   ```bash
      npm install
   ```
L'application sera accessible à l'adresse http://localhost:5173.

## Nom
EL ALAMI Adam
Elisee GUEPY LONKENG
Kyrian PENILLON
Roua BOUGHANMI
